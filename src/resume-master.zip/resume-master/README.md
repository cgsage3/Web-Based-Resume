resume
======

[View it here](https://nuterian.github.io/resume/)

Print the page to get a copy
